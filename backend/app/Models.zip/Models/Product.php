<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;


class Product extends Model
{
    use HasFactory;

    protected $primaryKey = 'product_id';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'product_id',
        'product_name',
        'category',
        'price',
        'quantity',
        'material',
        'color',
        'image',
    ];



    public function orders()
    {
        return $this->belongsToMany(Order::class, 'shopping_carts', 'product_id', 'order_id');
    }

}
